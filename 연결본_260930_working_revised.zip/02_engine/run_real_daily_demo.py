"""UME 수집 모듈을 실제로 붙여서 TIR·센서허브를 돌려보는 데모.

실행 (인터넷 필요):
    cd 02_engine
    export KRX_AUTH_KEY=발급받은키   # 없으면 KRX는 건너뛰고 네이버/야후로 폴백
    python run_real_daily_demo.py

일봉(df_daily)은 UME에서 실제로 받아오고, 분봉(df_intraday)은 아직 UME가
실시간/분봉을 지원하지 않아 mock을 그대로 쓴다 (KospiCockpitSensorHub.run의
df_intraday 자리). 이 둘을 섞어 쓰는 게 정직한 현재 상태다.
"""
import sys

from ume_daily_bridge import load_daily_from_ume
from kospi_cockpit_sensor_hub_v1_1 import (KospiCockpitSensorHub,
                                           generate_mock_intraday_bars,
                                           record_cascade_predictions, _LEDGER_AVAILABLE)
import tir_reflection_backtest_v1 as tir

if _LEDGER_AVAILABLE:
    import prediction_ledger as _pl


def main(count: int = 250) -> int:
    print(f"[1] UME에서 일봉 {count}개 수집 중 (KRX→네이버→야후 폴백)...")
    try:
        df_daily = load_daily_from_ume(count=count)
    except RuntimeError as e:
        print(f"[실패] 데이터 수집 실패: {e}")
        return 1
    print(f"    {len(df_daily)}개 수신 ({df_daily.index[0].date()} ~ {df_daily.index[-1].date()})")
    print(f"    주의: futures_close·trade_amount는 근사치"
          f" (FUTURES_IS_PROXY={df_daily.attrs.get('FUTURES_IS_PROXY')},"
          f" TRADE_AMOUNT_IS_PROXY={df_daily.attrs.get('TRADE_AMOUNT_IS_PROXY')})")

    print("\n[2] TIR v1 백테스트 (실제 일봉 기준)")
    tir_df = tir.run_backtest_v1(df_daily)

    print("\n[3] 센서 허브 (일봉=실제 UME, 분봉=mock)")
    hub = KospiCockpitSensorHub()
    demo_date = df_daily.index[-1]
    df_intraday = generate_mock_intraday_bars(n_bars=500, start=f"{demo_date.date()} 09:00")
    result = hub.run(df_intraday, df_daily)
    alerts = result[result["regime_alert"] == True]  # noqa: E712
    print(f"    regime_alert {len(alerts)}건 (분봉이 mock이라 참고용 — 실제 판단에 쓰지 말 것)")

    if _LEDGER_AVAILABLE:
        print("\n[4] 예측 원장: TIR 신호 기록")
        ledger = _pl.PredictionLedger()
        added = tir.record_tir_predictions(tir_df, ledger)
        print(f"    TIR 신호 {added}건 기록 (실제 평가는 수일 후 evaluate_tir_predictions() 호출)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(int(sys.argv[1]) if len(sys.argv) > 1 else 250))
