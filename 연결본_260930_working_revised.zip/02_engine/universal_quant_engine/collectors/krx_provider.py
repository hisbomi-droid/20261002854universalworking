"""KRX Open API Provider — 코스피 시리즈 일별 시세 (AUTH_KEY 방식).

엔드포인트: /svc/apis/idx/kospi_dd_trd  (기준일 basDd 하루 단위 조회)
인증키:     환경변수 KRX_AUTH_KEY (또는 KRX_API_KEY / KRX_OPENAPI_KEY) 또는 생성자 auth_key=
지원 심볼:  KOSPI, KOSPI200 (일봉 1d만)

동작 방식
  - 오늘부터 과거로 거슬러 올라가며 count개가 모일 때까지만 요청 (고정 1년치 전량 요청 안 함)
  - 하루 응답은 디스크에 캐시. 두 번째 실행부터는 캐시만 읽어 네트워크 요청이 거의 없음
  - 휴장일(빈 응답)도 캐시 (최근 2일은 아직 미게시일 수 있어 캐시하지 않음)
  - 네트워크 요청 사이에는 request_interval초 간격을 프로세스 간 공유로 보장
"""
import json
import os
import re
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import List, Optional, Tuple

from ..core.interfaces import MarketDataProvider
from ..core.models import MarketBar, Quote
from ._common import (DATA_ROOT, ProviderError, atomic_write_text,
                      http_get_json, to_num)

BASE_URL = "https://data-dbg.krx.co.kr/svc/apis/idx/kospi_dd_trd"
KEY_ENV_NAMES = ("KRX_AUTH_KEY", "KRX_API_KEY", "KRX_OPENAPI_KEY")

# 응답의 IDX_NM(공백 제거·대문자화)과 매칭할 이름
INDEX_NAMES = {
    "KOSPI": {"KOSPI", "코스피"},
    "KOSPI200": {"KOSPI200", "코스피200"},
}


def _norm_name(s: str) -> str:
    return re.sub(r"\s+", "", str(s)).upper()


class KrxOpenApiProvider(MarketDataProvider):
    name = "krx"

    def __init__(self, auth_key: Optional[str] = None,
                 cache_dir: Optional[str] = None,
                 request_interval: float = 1.0,
                 timeout: float = 15.0,
                 max_requests: int = 400):
        self._auth_key = auth_key
        self.cache_dir = Path(cache_dir or os.environ.get("KRX_CACHE_DIR")
                              or (DATA_ROOT / "krx_cache"))
        self.request_interval = request_interval
        self.timeout = timeout
        self.max_requests = max_requests
        self.last_status: str = "not_run"
        self.last_errors: List[str] = []

    # ── 설정 ────────────────────────────────────────────
    def _key(self) -> str:
        if self._auth_key:
            return self._auth_key.strip()
        for n in KEY_ENV_NAMES:
            v = os.environ.get(n)
            if v and v.strip():
                return v.strip()
        raise ProviderError("KRX AUTH_KEY 없음 (환경변수 KRX_AUTH_KEY 설정 필요)", "config")

    # ── 캐시 ────────────────────────────────────────────
    def _cache_path(self, day: date) -> Path:
        return self.cache_dir / f"kospi_dd_trd_{day:%Y%m%d}.json"

    def _read_cache(self, day: date) -> Optional[list]:
        path = self._cache_path(day)
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
            rows = obj.get("OutBlock_1")
            return rows if isinstance(rows, list) else None
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            # 깨진 캐시는 버리고 다시 받는다
            try:
                path.unlink()
            except OSError:
                pass
            return None

    def _fetch_day(self, day: date, key: str) -> Tuple[list, bool]:
        """(rows, 네트워크_사용여부). 캐시 우선."""
        cached = self._read_cache(day)
        if cached is not None:
            return cached, False
        obj = http_get_json(
            BASE_URL, headers={"AUTH_KEY": key},
            params={"basDd": day.strftime("%Y%m%d")},
            timeout=self.timeout, retries=2, backoff=1.0,
            throttle_key="krx", min_interval=self.request_interval)
        if not isinstance(obj, dict) or "OutBlock_1" not in obj:
            msg = (obj.get("result") or obj.get("message") or obj) if isinstance(obj, dict) else obj
            raise ProviderError(f"KRX 응답 오류: {str(msg)[:200]}", "parse")
        rows = obj.get("OutBlock_1") or []
        if not isinstance(rows, list):
            rows = []
        # 오늘·어제 빈 응답은 '아직 미게시'일 수 있으므로 캐시하지 않는다
        if rows or day < date.today() - timedelta(days=2):
            atomic_write_text(self._cache_path(day),
                              json.dumps({"OutBlock_1": rows}, ensure_ascii=False))
        return rows, True

    # ── 표준 인터페이스 ──────────────────────────────────
    def get_bars(self, symbol: str, timeframe: str = "1d",
                 count: int = 200) -> List[MarketBar]:
        if timeframe != "1d":
            raise ProviderError(f"KRX는 일봉(1d)만 지원 (요청: {timeframe})", "unsupported")
        names = INDEX_NAMES.get(symbol.upper())
        if names is None:
            raise ProviderError(f"KRX 미지원 심볼: {symbol} (지원: {list(INDEX_NAMES)})", "unsupported")
        key = self._key()
        count = max(1, int(count))

        self.last_errors = []
        bars: List[MarketBar] = []
        now = datetime.now()
        oldest = date.today() - timedelta(days=max(count * 2, count + 30))
        day, requests_used = date.today(), 0
        while day >= oldest and len(bars) < count and requests_used < self.max_requests:
            if day.weekday() < 5:
                try:
                    rows, used_net = self._fetch_day(day, key)
                    requests_used += int(used_net)
                    for row in rows:
                        if _norm_name(row.get("IDX_NM", "")) in names:
                            bar = self._to_bar(symbol, day, row, now)
                            if bar:
                                bars.append(bar)
                            break
                except ProviderError as exc:
                    if exc.kind in ("config",) or (exc.kind == "http" and "HTTP 401" in str(exc)) \
                            or (exc.kind == "http" and "HTTP 403" in str(exc)):
                        raise  # 인증 문제는 하루씩 반복해도 소용없다 → 즉시 중단
                    requests_used += 1
                    self.last_errors.append(f"{day:%Y-%m-%d}: {exc}")
                    if len(self.last_errors) >= 5 and not bars:
                        break  # 초반부터 연속 실패 → 소스 장애로 보고 중단
            day -= timedelta(days=1)

        if not bars:
            self.last_status = "failed"
            tail = f"; 마지막 오류: {self.last_errors[-1]}" if self.last_errors else ""
            raise ProviderError("KRX Open API 데이터 없음" + tail, "empty")
        bars.sort(key=lambda b: b.timestamp)
        bars = bars[-count:]
        self.last_status = ("ok" if not self.last_errors and len(bars) >= count
                            else f"partial(bars={len(bars)}, errors={len(self.last_errors)})")
        return bars

    @staticmethod
    def _to_bar(symbol: str, day: date, row: dict, now: datetime) -> Optional[MarketBar]:
        o, h = to_num(row.get("OPNPRC_IDX")), to_num(row.get("HGPRC_IDX"))
        l, c = to_num(row.get("LWPRC_IDX")), to_num(row.get("CLSPRC_IDX"))
        if None in (o, h, l, c):
            return None  # 값이 비어 있으면 임의로 채우지 않고 건너뛴다
        ts = datetime(day.year, day.month, day.day)
        return MarketBar(
            symbol=symbol, timestamp=ts, open=o, high=h, low=l, close=c,
            volume=to_num(row.get("ACC_TRDVOL")) or 0.0, source="krx",
            source_timestamp=ts, received_timestamp=now, processed_timestamp=datetime.now(),
            raw_id=f"krx-{symbol}-{day:%Y%m%d}")

    def get_quote(self, symbol: str) -> Optional[Quote]:
        b = self.get_bars(symbol, "1d", 1)[-1]
        return Quote(symbol=symbol, timestamp=b.timestamp, price=b.close,
                     volume=b.volume, source=self.name, quality="delayed")

    def health(self) -> bool:
        try:
            self._key()
            return True
        except ProviderError:
            return False
