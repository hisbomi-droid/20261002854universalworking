"""Naver Finance Provider — 코스피/코스피200 일봉 (공개 웹 데이터, 인증 불필요).

기존 kospi_model_v3.py 가 사용하던 동일 엔드포인트:
  https://api.stock.naver.com/chart/domestic/index/{KOSPI|KOSPI200}?periodType=dayCandle&count=N
비공식 공개 엔드포인트라 예고 없이 바뀔 수 있다 → 실패 시 다음 소스로 폴백하도록 설계.
"""
from datetime import datetime
from typing import List, Optional

from ..core.interfaces import MarketDataProvider
from ..core.models import MarketBar, Quote
from ._common import ProviderError, http_get_json, to_num

URL = "https://api.stock.naver.com/chart/domestic/index/{code}"
SYMBOL_MAP = {"KOSPI": "KOSPI", "KOSPI200": "KOSPI200"}


class NaverProvider(MarketDataProvider):
    name = "naver"

    def __init__(self, request_interval: float = 1.0, timeout: float = 10.0):
        self.request_interval = request_interval
        self.timeout = timeout
        self.last_status: str = "not_run"

    def get_bars(self, symbol: str, timeframe: str = "1d",
                 count: int = 200) -> List[MarketBar]:
        if timeframe != "1d":
            raise ProviderError(f"네이버는 일봉(1d)만 지원 (요청: {timeframe})", "unsupported")
        code = SYMBOL_MAP.get(symbol.upper())
        if code is None:
            raise ProviderError(f"네이버 미지원 심볼: {symbol} (지원: {list(SYMBOL_MAP)})", "unsupported")
        count = max(1, int(count))
        payload = http_get_json(
            URL.format(code=code), params={"periodType": "dayCandle", "count": count},
            timeout=self.timeout, retries=2, backoff=1.0,
            throttle_key="naver", min_interval=self.request_interval)
        rows = payload.get("priceInfos") if isinstance(payload, dict) else None
        if not rows:
            self.last_status = "failed"
            raise ProviderError("네이버 응답에 priceInfos 없음", "empty")

        now, bars = datetime.now(), []
        for r in rows:
            try:
                ts = datetime.strptime(str(r["localDate"]), "%Y%m%d")
            except (KeyError, ValueError):
                continue
            o, h, l, c = (to_num(r.get(k)) for k in
                          ("openPrice", "highPrice", "lowPrice", "closePrice"))
            if None in (o, h, l, c):
                continue
            bars.append(MarketBar(
                symbol=symbol, timestamp=ts, open=o, high=h, low=l, close=c,
                volume=to_num(r.get("accumulatedTradingVolume")) or 0.0, source=self.name,
                source_timestamp=ts, received_timestamp=now,
                processed_timestamp=datetime.now(), raw_id=f"naver-{symbol}-{ts:%Y%m%d}"))
        if not bars:
            self.last_status = "failed"
            raise ProviderError("네이버 응답을 표준 바로 변환하지 못함", "parse")
        bars.sort(key=lambda b: b.timestamp)
        bars = bars[-count:]
        self.last_status = "ok" if len(bars) >= count else f"partial(bars={len(bars)})"
        return bars

    def get_quote(self, symbol: str) -> Optional[Quote]:
        b = self.get_bars(symbol, "1d", 1)[-1]
        return Quote(symbol=symbol, timestamp=b.timestamp, price=b.close,
                     volume=b.volume, source=self.name, quality="delayed")

    def health(self) -> bool:
        return True  # 별도 핑을 보내지 않는다 (불필요한 요청 방지)
