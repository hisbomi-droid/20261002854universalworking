"""Yahoo Finance Provider — chart API 직접 호출 (yfinance 패키지 불필요).

KOSPI→^KS11, KOSPI200→^KS200 로 매핑하고, 그 외 심볼(^GSPC, AAPL 등)은 그대로 전달.
주의: 야후는 한국 지수를 갱신하지 않는 현상이 있었음(2026-09-15 확인) →
      마지막 봉의 날짜가 오래되면 ReliabilityEngine의 freshness 점수가 낮아지고,
      폴백 순서상 KRX·네이버 다음에 배치한다.
"""
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from ..core.interfaces import MarketDataProvider
from ..core.models import MarketBar, Quote
from ._common import ProviderError, http_get_json, to_num

URL = "https://query1.finance.yahoo.com/v8/chart/{symbol}"
SYMBOL_MAP = {"KOSPI": "^KS11", "KOSPI200": "^KS200"}


def _range_for(count: int) -> str:
    """필요한 봉 수(영업일)를 덮는 가장 작은 range."""
    for limit, rng in ((20, "1mo"), (60, "3mo"), (120, "6mo"), (250, "1y"),
                       (500, "2y"), (1250, "5y"), (2500, "10y")):
        if count <= limit:
            return rng
    return "max"


class YahooProvider(MarketDataProvider):
    name = "yahoo"

    def __init__(self, request_interval: float = 1.0, timeout: float = 15.0):
        self.request_interval = request_interval
        self.timeout = timeout
        self.last_status: str = "not_run"

    def get_bars(self, symbol: str, timeframe: str = "1d",
                 count: int = 200) -> List[MarketBar]:
        if timeframe != "1d":
            raise ProviderError(f"야후는 일봉(1d)만 지원 (요청: {timeframe})", "unsupported")
        ysym = SYMBOL_MAP.get(symbol.upper(), symbol)
        count = max(1, int(count))
        payload = http_get_json(
            URL.format(symbol=ysym),
            params={"range": _range_for(count), "interval": "1d", "includePrePost": "false"},
            timeout=self.timeout, retries=2, backoff=1.0,
            throttle_key="yahoo", min_interval=self.request_interval)

        chart = payload.get("chart", {}) if isinstance(payload, dict) else {}
        if chart.get("error"):
            self.last_status = "failed"
            raise ProviderError(f"야후 오류: {str(chart['error'])[:160]}", "http")
        result = (chart.get("result") or [None])[0]
        if not result or not result.get("timestamp"):
            self.last_status = "failed"
            raise ProviderError("야후 응답에 시세 없음", "empty")

        q = (result.get("indicators", {}).get("quote") or [{}])[0]
        offset = timedelta(seconds=int(result.get("meta", {}).get("gmtoffset", 0) or 0))
        now, bars = datetime.now(), []
        for i, t in enumerate(result["timestamp"]):
            try:
                o, h, l, c = (to_num(q[k][i]) for k in ("open", "high", "low", "close"))
            except (KeyError, IndexError):
                continue
            if None in (o, h, l, c):
                continue  # 휴장/미완성 봉(null)은 건너뛴다
            local = datetime.fromtimestamp(int(t), tz=timezone.utc) + offset
            ts = datetime(local.year, local.month, local.day)
            vols = q.get("volume") or []
            vol = to_num(vols[i]) if i < len(vols) else None
            bars.append(MarketBar(
                symbol=symbol, timestamp=ts, open=o, high=h, low=l, close=c,
                volume=vol or 0.0, source=self.name, source_timestamp=ts,
                received_timestamp=now, processed_timestamp=datetime.now(),
                raw_id=f"yahoo-{ysym}-{ts:%Y%m%d}"))
        if not bars:
            self.last_status = "failed"
            raise ProviderError("야후 응답을 표준 바로 변환하지 못함", "parse")
        bars.sort(key=lambda b: b.timestamp)
        bars = bars[-count:]
        self.last_status = "ok" if len(bars) >= count else f"partial(bars={len(bars)})"
        return bars

    def get_quote(self, symbol: str) -> Optional[Quote]:
        b = self.get_bars(symbol, "1d", 1)[-1]
        return Quote(symbol=symbol, timestamp=b.timestamp, price=b.close,
                     volume=b.volume, source=self.name, quality="delayed")

    def health(self) -> bool:
        return True
