# 데이터 수집 ↔ 신뢰도검증 연결본 (2026-09-30)

이번에 한 일 두 가지: **(1) 지난번 수집 모듈의 실제 버그 수정, (2) 수집 모듈을 신뢰도검증 모듈에 실제로 연결.**

```
02_engine/
├── universal_quant_engine/           (수집 엔진, 버그 수정 반영됨)
├── ume_daily_bridge.py                ★ 연결 어댑터 (새로 만든 핵심 파일)
├── prediction_ledger.py
├── tir_reflection_backtest_v1.py      (load_market_data() 가 이제 실제로 동작함)
├── kospi_cockpit_sensor_hub_v1_1.py
├── run_real_daily_demo.py             (실제 인터넷으로 전체 파이프라인 돌려보는 데모)
└── test_connection_v1.py              (가짜 응답으로 연결 전체를 검증하는 테스트)
```

## (1) 수집 모듈 버그 수정 — item5 적용
`market("KOSPI")` 수집 후 `market("KOSPI200")`을 또 수집하면, `verify()`/`get_all_sources()`가 심볼 구분 없이 **마지막에 수집한 종목 데이터를 섞어 쓰던** 문제를 고쳤습니다(심볼별 캐시 분리). 요청한 봉 수보다 적게 받아온 경우(`partial`)도 이제 리포트에 남습니다. 기존 테스트 14/14 + 새 테스트 29/29 통과.

## (2) 연결 — `ume_daily_bridge.py`
`tir_reflection_backtest_v1.load_market_data()`가 이제 이 브릿지를 통해 UME에서 실제 일봉을 받아옵니다. 센서 허브의 `df_daily`도 같은 형식이라 그대로 꽂힙니다.

```python
from ume_daily_bridge import load_daily_from_ume
df_daily = load_daily_from_ume(count=250)   # KRX→네이버→야후 폴백
```

**연결 과정에서 실제로 하나 더 잡은 버그:** 브릿지가 만든 표의 인덱스 이름(`timestamp`)이 센서 허브가 기대하는 이름(무명 인덱스)과 달라서 `KeyError: '_ts'`로 깨졌습니다. 인덱스 이름을 맞춰서 수정했습니다.

## 정직하게 밝혀둘 근사치 2가지 (실제 값이 아님)
| 컬럼 | 실제로는 |
|---|---|
| `futures_close` | 코스피200 **선물**이 아니라 코스피200 **현물** 지수. UME에 선물 데이터 소스가 없어서임. TIR의 theta_proxy(베이시스)가 실제 선물-현물 베이시스와 다른 값이 됨 |
| `trade_amount` | 실제 거래대금(원화)이 아니라 종가×거래량 근사. KRX 응답에 거래대금 필드가 없어서임 |

`load_daily_from_ume()`가 반환하는 DataFrame의 `.attrs["FUTURES_IS_PROXY"]` / `.attrs["TRADE_AMOUNT_IS_PROXY"]`로 항상 확인 가능합니다.

## 아직 연결 안 된 것
- **센서 허브의 분봉(df_intraday)은 여전히 mock입니다.** UME는 일봉만 지원해서, 분봉은 실제 증권사 실시간 어댑터(2026-09-29 메모의 D단계)가 있어야 연결 가능합니다. `run_real_daily_demo.py`는 "일봉=실제, 분봉=mock"으로 섞어 돌리는 정직한 현재 상태를 보여줍니다.
- `friction_engine.py` 파일 자체가 없어 센서 허브는 여전히 폴백 프록시로 마찰지수를 계산합니다.

## 검증
- `python -m universal_quant_engine.tests.test_collectors_v1` → 29/29
- `python -m universal_quant_engine.tests.test_v1` → 14/14
- `python test_connection_v1.py` → 6/6 (가짜 응답으로 수집→브릿지→TIR→센서허브→원장 끝까지 실행 확인)
- `python run_real_daily_demo.py` → **실제 인터넷 환경에서 아직 실행 안 해봄** (이 환경은 인터넷 차단)
